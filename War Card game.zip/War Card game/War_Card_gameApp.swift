//
//  War_Card_gameApp.swift
//  War Card game
//
//  Created by Aleksandar Markovic on 5/18/23.
//

import SwiftUI

@main
struct War_Card_gameApp: App {
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
